"""
Waveguide
=========

Observe guided propagation in one straight dielectric waveguide. The animation
is the single result of this example.
"""

# %%
# Importing the necessary packages
from TypedUnit import ureg
from MPSPlots import colormaps

from LightWave2D.grid import Grid
from LightWave2D.experiment import Experiment

# %%
# Define the simulation grid
grid = Grid(
    resolution=0.1 * ureg.micrometer,  # Grid resolution in meters
    size_x=50 * ureg.micrometer,  # Grid size in the x direction in meters
    size_y=15 * ureg.micrometer,  # Grid size in the y direction in meters
    n_steps=100,  # Number of time steps for the simulation
)

# Initialize the experiment with the defined grid
experiment = Experiment(grid=grid)

# %%
# Add a waveguide to the experiment
scatterer = experiment.add_waveguide(
    position_0=("0%", "50%"),  # Starting position of the waveguide
    position_1=("100%", "50%"),  # Ending position of the waveguide
    width=2 * ureg.micrometer,  # Width of the waveguide in meters
    epsilon_r=2,  # Relative permittivity of the waveguide
)

# Add a line source to the experiment
source = experiment.add_line_source(
    wavelength=1550 * ureg.nanometer,  # Wavelength of the source in meters
    position_0=("20%", "45%"),  # Starting position of the source
    position_1=("20%", "55%"),  # Ending position of the source
    amplitude=10,  # Amplitude of the source
)

# %%
# Add a perfectly matched layer (PML) to absorb boundary reflections
experiment.add_pml(
    order=1,  # Order of the PML polynomial profile
    width="10%",  # Width of the PML region as a percentage of grid size
    sigma_max=5000 * (ureg.siemens / ureg.meter),  # Maximum conductivity for the PML
)

# %%
# Run the FDTD simulation
experiment.run()

# %%
# Animate guided propagation.
animation = experiment.render_propagation(
    skip_frame=5,  # Number of frames to skip in the animation
    colormap=colormaps.polytechnique.red_black_blue,  # Colormap for the animation
    enhance_contrast=4,  # Enhance contrast for better visualization
    save_as="./waveguide.gif",  # Save the animation as a GIF file
    fps=30,
)
